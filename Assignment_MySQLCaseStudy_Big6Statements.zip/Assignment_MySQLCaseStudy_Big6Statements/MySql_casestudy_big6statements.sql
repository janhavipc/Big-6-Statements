-- 1)

select * from staff;

select
     first_name,
     last_name,
     email,
     store_id
  from staff;   
  
  
-- 2)

select * from inventory;

select
     count(inventory_id) as Inventory_Count ,
      store_id
   from inventory
   group by store_id;
   
   
   -- 3)
   
   select * from customer;
   
   select
         store_id as Store_Id,       -- (aggregator)
         active as Active_Status,     -- (aggregator)
      count(active) as No_of_Customers    -- (aggregated value)
      from customer
      group by store_id, active 
      order by store_id asc;
   
   -- 4)
   
   select * from customer;
   
   select
    count(email) as Email_Count_Of_Customers
    from customer;

   -- 5)

select * from film_category;
select * from inventory;
select * from category;


select
     inventory.store_id,
     inventory.inventory_id,
     film_category.film_id,
     film_category.category_id,
     category.name as Category_Of_Films,
 count(film_category.film_id)    as No_Of_Films
 from inventory
 left join film_category
 on inventory.film_id=film_category.film_id
 left join category
 on film_category.category_id=category.category_id
 group by film_category.category_id;
     
  
  -- 6)
  
  select * from film;
  
  select replacement_cost,
      count(film_id),
      avg(rental_rate),
      min(rental_rate),
      max(rental_rate)
  from film
  group by replacement_cost;
  
  -- 7)
  
  select * from payment;
  select * from film;
  
  select
        avg(amount) as Average_payment$,
        max(amount) as Maximum_Payment$
     from payment;   
     
     -- 8)
     
     select * from rental;
     
     select
          customer_id,
        count(rental_id) as Rental_Count
     from rental
     group by customer_id
     order by count(rental_id) desc;